const { chromium } = require("playwright");
const assert = require("node:assert/strict");
const path = require("node:path");
const fs = require("node:fs");

(async () => {
  const browser = await chromium.launch({ channel: "chrome", headless: true });
  const checks = [], errors = [], geometry = [];
  const artifacts = process.env.PROTOTYPE_ARTIFACT_DIR || __dirname;
  const check = (name, condition) => { assert.ok(condition, name); checks.push(name); };
  try {
    const page = await browser.newPage({ viewport: { width: 1512, height: 1080 }, reducedMotion: "reduce" });
    page.on("pageerror", error => errors.push(error.message));
    await page.goto(process.env.PROTOTYPE_URL || "http://127.0.0.1:8765/");
    await page.locator("#reset-demo").click();
    check("Short icon cards stay compact without horizontal overflow", await page.locator('[data-strip-key="design:main"]').evaluate(element => element.scrollWidth === element.clientWidth && element.querySelectorAll(".strip-agent").length === 2));
    await page.locator("#stress-button").click();
    await page.evaluate(() => { state.workspaceCollapsed.design = true; state.workspaceCollapsed.scratch = true; render(); });
    const identity = () => page.evaluate(() => JSON.stringify({
      active: state.active, dismissed: state.dismissed, panes: state.panes,
      tags: state.tags, tagColors: state.tagColors,
      surfaces: surfaces.map(({ id, parent, workspace, worktree }) => ({ id, parent, workspace, worktree })),
      tasks: observedChildren.map(({ id, parent, state, outcome }) => ({ id, parent, state, outcome }))
    }));
    const original = await identity();
    for (const width of [280, 350, 460]) {
      await page.locator("#sidebar-width").fill(String(width));
      for (const grouping of ["worktrees", "subagents", "workspace"]) {
        await page.locator(`[data-grouping="${grouping}"]`).click();
        const measured = await page.evaluate(() => {
          const sidebar = document.querySelector("#sidebar"), outline = document.querySelector("#workspaces");
          const lines = [...document.querySelectorAll('[data-task-parent="stress-depth-12"] .task-line')].map(element => {
            const line = element.getBoundingClientRect(), name = element.querySelector(".task-name"), status = element.querySelector(".task-status").getBoundingClientRect();
            return { left: line.left, right: line.right, nameWidth: name.clientWidth, statusRight: status.right };
          });
          return {
            lines, indent: parseFloat(getComputedStyle(document.querySelector('[data-task-parent="stress-task-depth-1"]')).marginLeft),
            sidebarWidth: sidebar.clientWidth, sidebarContent: sidebar.scrollWidth,
            outlineWidth: outline.clientWidth, outlineContent: outline.scrollWidth,
            right: sidebar.getBoundingClientRect().right
          };
        });
        geometry.push({ width, grouping, ...measured });
        check(`${width}px ${grouping}: twelve nested lines retain their exact ancestry`, measured.lines.length === 12);
        check(`${width}px ${grouping}: only the left edge steps inward`, [5, 8].includes(measured.indent) && measured.lines.slice(1).every((line, index) => Math.abs(line.left - measured.lines[index].left - measured.indent) < 1));
        check(`${width}px ${grouping}: right edge and state column stay aligned`, measured.lines.every(line => Math.abs(line.right - measured.lines[0].right) < 1 && Math.abs(line.statusRight - measured.lines[0].statusRight) < 1));
        check(`${width}px ${grouping}: deepest names retain at least 40px`, measured.lines.every(line => line.nameWidth >= 40));
        check(`${width}px ${grouping}: no horizontal sidebar or outline overflow`, measured.sidebarContent <= measured.sidebarWidth && measured.outlineContent <= measured.outlineWidth);
        check(`${width}px ${grouping}: all states remain inside the sidebar`, measured.lines.every(line => line.statusRight <= measured.right));
        if (grouping === "worktrees") {
          check(`${width}px: branch labels and counts stay inside their heading`, await page.locator('[data-workspace="stress"] .group-heading').evaluateAll(elements => elements.every(element => {
            const heading = element.getBoundingClientRect(), label = element.querySelector(".branch-label"), count = element.querySelector(".count").getBoundingClientRect();
            return element.scrollWidth <= element.clientWidth && label.getBoundingClientRect().right <= count.left && count.right <= heading.right + 1 && label.title.includes("UnbrokenSyntheticIdentifier") && getComputedStyle(label).textOverflow === "ellipsis";
          })));
        }
      }
    }
    await page.locator("#sidebar-width").fill("350");
    await page.locator('[data-grouping="subagents"]').click();
    await page.locator('[data-task-parent="stress-depth-12"]').screenshot({ path: path.join(artifacts, "rapid-01-right-triangle.png") });
    await page.locator('[data-grouping="worktrees"]').click();
    await page.locator('[data-expand="stress:stress-wide"]').first().click();
    const strip = page.locator('[data-worktree-id="tree-stress-wide"] .summary-strip');
    const scroller = strip.locator(".strip-scroll");
    const iconCount = await page.evaluate(() => visibleAgents("stress", "worktrees").filter(item => item.worktree === "stress-wide").length);
    const lastIcon = strip.locator(".strip-agent").last();
    const lastID = await lastIcon.getAttribute("data-focus");
    check("Collapsed card contains every participant rather than a four-agent sample", await strip.locator(".strip-agent").count() === iconCount && iconCount > 4);
    check("Collapsed card is icons only, with no tags or names in its visible text", await strip.locator("[data-tag-slug], .strip-tags-more, .strip-participant").count() === 0 && (await strip.locator(".strip-agent").allTextContents()).every(text => text.trim() === ""));
    check("Each icon retains exact identity and state for assistive technology", await strip.locator(".strip-agent").evaluateAll(elements => elements.every(element => element.getAttribute("aria-label").includes(byId(element.dataset.focus).name) && element.querySelector(".state-dot").getAttribute("aria-label") === stateLabel(byId(element.dataset.focus)))));
    for (const width of [280, 350, 460]) {
      await page.locator("#sidebar-width").fill(String(width));
      const bounds = await strip.evaluate(element => {
        const scroller = element.querySelector(".strip-scroll"), icons = [...element.querySelectorAll(".strip-agent")];
        return {
          tops: icons.map(icon => icon.getBoundingClientRect().top),
          widths: icons.map(icon => icon.getBoundingClientRect().width),
          height: element.getBoundingClientRect().height,
          viewport: scroller.clientWidth, content: scroller.scrollWidth,
          outerWidth: element.clientWidth, outerContent: element.scrollWidth
        };
      });
      check(`${width}px: icons remain one row without shrinking into a grid`, bounds.tops.every(top => Math.abs(top - bounds.tops[0]) < 1) && bounds.widths.every(width => width === 40) && bounds.height <= 60);
      check(`${width}px: only the card's inner viewport scrolls horizontally`, bounds.content > bounds.viewport && bounds.outerContent <= bounds.outerWidth && await page.locator("#workspaces").evaluate(element => element.scrollWidth <= element.clientWidth));
    }
    await page.locator("#sidebar-width").fill("350");
    await scroller.hover();
    const outlineTop = await page.locator("#workspaces").evaluate(element => element.scrollTop);
    await page.mouse.wheel(600, 0);
    await page.waitForFunction(() => document.querySelector('[data-strip-key="stress:stress-wide"]').scrollLeft > 0);
    check("Horizontal wheel scroll stays local to the icon card", await page.locator("#workspaces").evaluate((element, top) => element.scrollLeft === 0 && element.scrollTop === top, outlineTop));
    await scroller.evaluate(element => { element.scrollLeft = 0; });
    await scroller.focus();
    await page.keyboard.press("ArrowRight");
    await page.waitForFunction(() => document.querySelector('[data-strip-key="stress:stress-wide"]').scrollLeft > 0);
    check("The card supports keyboard horizontal scrolling", await scroller.evaluate(element => element.matches(":focus-visible")));
    await lastIcon.focus();
    await page.waitForFunction(id => {
      const card = document.querySelector("#hover-card");
      return !card.hidden && card.querySelector(".hover-title")?.textContent.includes(byId(id).name);
    }, lastID);
    check("Keyboard reaches and previews the last offscreen agent without selecting it", await page.evaluate(id => document.activeElement.dataset.focus === id && state.active === "stress-root", lastID) && await lastIcon.evaluate(element => {
      const icon = element.getBoundingClientRect(), viewport = element.closest(".strip-scroll").getBoundingClientRect();
      return icon.left >= viewport.left && icon.right <= viewport.right;
    }));
    check("Hovering an icon still provides its full tags", await page.locator("#hover-card [data-tag-slug]").count() === 6);
    await page.keyboard.press("Escape");
    await page.keyboard.press("Enter");
    check("Choosing an icon focuses its actual chat and keeps the card scrolled", await page.locator("#pinned-details").getAttribute("data-active") === lastID && await scroller.evaluate(element => element.scrollLeft > 0) && await lastIcon.getAttribute("aria-current") === "true");
    assert.deepEqual(JSON.parse(await identity()), { ...JSON.parse(original), active: lastID });
    const beforeRerender = await scroller.evaluate(element => element.scrollLeft);
    await page.evaluate(() => commit());
    check("Unrelated rerenders preserve the card's scroll position", Math.abs(await scroller.evaluate(element => element.scrollLeft) - beforeRerender) <= 1);
    await lastIcon.focus();
    await page.keyboard.press("Alt+ArrowUp");
    check("Icon cards preserve sibling-only keyboard reordering", await page.evaluate(id => {
      const order = state.sidebarOrders["members:stress:stress-wide"];
      return order.indexOf(id) === order.length - 2;
    }, lastID));
    await page.evaluate(() => { delete state.sidebarOrders["members:stress:stress-wide"]; commit(); });
    await strip.locator('[data-focus="stress-root"]').focus();
    await page.keyboard.press("Enter");
    check("Icon browsing never changes tags or agent ownership", await identity() === original);
    await page.keyboard.press("Escape");
    await strip.screenshot({ path: path.join(artifacts, "rapid-06-horizontal-icons.png") });
    await strip.locator(".expand-strip").click();
    check("The card's separate expansion control opens the real agent rows", await strip.count() === 0 && await page.locator('[data-row="stress-root"]').isVisible());
    check("Expanded rows and pinned details retain their tags", await page.locator('[data-row="stress-root"] [data-tag-slug]').count() === 6 && await page.locator("#pinned-details [data-tag-slug]").count() === 6);

    const toggle = page.locator('[data-toggle-tasks="stress-root"]');
    await toggle.click();
    check("Each agent can collapse its internal tasks independently", await toggle.getAttribute("aria-expanded") === "false" && !await page.locator("#internal-tasks-stress-root").isVisible() && await page.locator("#internal-tasks-stress-agent-1").isVisible());
    check("Collapsed tasks retain working and attention summaries", await toggle.locator(".task-group-summary .task-spinner").count() === 1 && (await toggle.getAttribute("aria-label")).includes("blocked, failed or needing attention"));
    check("Task collapse preserves actual child chats and all tab identities", await page.locator('[data-row="stress-agent-1"]').isVisible() && await page.locator("#native-layout [data-drag]").count() === 65 && await identity() === original);
    await page.locator('[data-task-parent="stress-root"]').screenshot({ path: path.join(artifacts, "rapid-05-collapsed-tasks.png") });
    for (const grouping of ["subagents", "workspace", "worktrees"]) {
      await page.locator(`[data-grouping="${grouping}"]`).click();
      check(`${grouping}: per-parent task disclosure persists without filtering real tabs`, await toggle.getAttribute("aria-expanded") === "false" && !await page.locator("#internal-tasks-stress-root").isVisible() && await page.locator('[data-row="stress-root"]').isVisible());
    }
    await page.reload();
    check("Per-agent task collapse survives reload", await toggle.getAttribute("aria-expanded") === "false" && await identity() === original);
    await page.locator('[data-toggle-finished="stress"]').click();
    check("Idle reveal does not force a collapsed task group open", await toggle.getAttribute("aria-expanded") === "false" && !await page.locator("#internal-tasks-stress-root").isVisible());
    await toggle.focus();
    await page.keyboard.press("Space");
    check("Keyboard expands tasks and retains disclosure focus", await toggle.getAttribute("aria-expanded") === "true" && await page.locator("#internal-tasks-stress-root").isVisible() && await page.evaluate(() => document.activeElement.dataset.toggleTasks === "stress-root"));
    await page.locator('[data-toggle-finished="stress"]').click();

    const preview = async id => {
      const row = page.locator(`[data-row="${id}"]`);
      await row.scrollIntoViewIfNeeded();
      await page.mouse.move(1450, 20);
      await page.evaluate(() => new Promise(resolve => requestAnimationFrame(() => requestAnimationFrame(resolve))));
      await page.locator("#global-grouping button").first().focus();
      await row.locator(".row-main").focus();
      await page.locator("#hover-card").waitFor({ state: "visible" });
    };
    const cardFits = () => page.locator("#hover-card").evaluate(element => {
      const box = element.getBoundingClientRect();
      return element.scrollWidth <= element.clientWidth && box.left >= 0 && box.right <= innerWidth &&
        [...element.querySelectorAll("p, h3, footer, .detail-metrics, .detail-path, .detail-fields, .hover-identity")].every(child => {
          const bounds = child.getBoundingClientRect();
          return bounds.left >= box.left && bounds.right <= box.right;
        });
    });
    for (const id of ["stress-agent-8", "stress-browser-1", "stress-terminal-3"]) {
      await preview(id);
      check(`${id}: hover wraps all content with no horizontal overflow`, await cardFits());
      check(`${id}: full identity remains in the preview`, await page.evaluate(id => document.querySelector("#hover-card .hover-title").textContent.includes(byId(id).name), id));
      if (id === "stress-agent-8") {
        await page.locator("#hover-card").evaluate(element => { element.scrollTop = element.scrollHeight; element.scrollLeft = 100; });
        check("Long hover remains vertically scrollable but not horizontally", await page.locator("#hover-card").evaluate(element => element.scrollTop > 0 && element.scrollLeft === 0));
        check("Raw copy values are not shortened to fit the hover", (await page.locator('#hover-card [data-field="child-history"] [data-copy-value]').getAttribute("data-copy-value")).length >= 4000);
        await page.locator("#hover-card").screenshot({ path: path.join(artifacts, "rapid-02-wrapped-hover.png") });
      }
      await page.keyboard.press("Escape");
      await page.locator(`[data-row="${id}"] .row-main`).click();
      check(`${id}: pinned details cannot force sidebar scrolling`, await page.locator("#pinned-details").evaluate(element => element.scrollWidth <= element.clientWidth));
    }
    await page.locator("#stress-long-name").check();
    const workspaceName = page.locator('[data-workspace="stress"] .workspace-select');
    await page.mouse.move(1450, 20);
    await workspaceName.scrollIntoViewIfNeeded();
    await page.evaluate(() => new Promise(resolve => requestAnimationFrame(() => requestAnimationFrame(resolve))));
    const nameBox = await workspaceName.boundingBox();
    await page.mouse.move(nameBox.x + 20, nameBox.y + nameBox.height / 2);
    await page.locator("#hover-card").waitFor({ state: "visible" });
    check("Paragraph workspace preview also wraps without horizontal scrolling", await cardFits());
    await page.keyboard.press("Escape");
    await page.locator("#stress-long-name").uncheck();
    await page.locator("#sidebar-width").fill("280");
    await page.setViewportSize({ width: 360, height: 740 });
    await preview("stress-agent-8");
    check("Hover remains contained on a narrow viewport", await cardFits());
    check("No runtime errors", errors.length === 0);
    fs.writeFileSync(path.join(artifacts, "rapid-fire-verification.json"), JSON.stringify({ checkedAt: new Date().toISOString(), fixes: [1, 2, 3, 5, 6], superseded: [4], checks, geometry, errors }, null, 2));
    console.log(`PASS: ${checks.length} rapid-fire regression checks; RF-06 supersedes RF-04.`);
  } finally {
    await browser.close();
  }
})().catch(error => { console.error(error); process.exitCode = 1; });
