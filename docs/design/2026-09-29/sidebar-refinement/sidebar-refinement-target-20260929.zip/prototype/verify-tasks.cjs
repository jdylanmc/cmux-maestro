const { chromium } = require("playwright");
const assert = require("node:assert/strict");
const path = require("node:path");

(async () => {
  const browser = await chromium.launch({ channel: "chrome", headless: true });
  const checks = [], errors = [], requests = [];
  const check = (name, condition) => { assert.ok(condition, name); checks.push(name); };
  const baseURL = process.env.PROTOTYPE_URL || "http://127.0.0.1:8765/";
  const artifacts = process.env.PROTOTYPE_ARTIFACT_DIR || __dirname;
  try {
    const page = await browser.newPage({ viewport: { width: 1512, height: 1080 }, reducedMotion: "no-preference" });
    page.on("pageerror", error => errors.push(error.message));
    page.on("request", request => requests.push(request.url()));
    await page.goto(baseURL);
    await page.locator("#reset-demo").click();
    const task = id => page.locator(`[data-observed="${id}"]`);
    const eye = page.locator('[data-toggle-finished="design"]');
    const model = () => page.evaluate(() => JSON.stringify({
      surfaces, active: state.active, panes: state.panes, dismissed: state.dismissed,
      icons: state.icons, pets: state.pets, beats: state.beats
    }));
    const initial = await model();
    check("Internal tasks are a compact list beneath their exact tab", await page.locator('[data-row="implementer"] + [data-task-parent="implementer"]').count() === 1);
    check("Working, finished and failed tasks are present by default", await task("task-source").count() === 1 && await task("task-review").count() === 1 && await task("task-check").count() === 1);
    check("Idle internal tasks are absent by default", await task("task-idle").count() === 0);
    check("Blocked task stays visible with a truthful accessible state", await task("task-blocked").locator(".task-status").getAttribute("aria-label") === "Blocked");
    check("No task identity icons, pets, selection, move or chat actions", await page.locator(".internal-tasks .icon, .internal-tasks .identity-icon, .internal-tasks .pet, .internal-tasks [data-focus], .internal-tasks [data-move], .internal-tasks [data-menu], .internal-tasks [data-dismiss], .internal-tasks [draggable], .internal-tasks [tabindex]").count() === 0);
    check("State words do not appear in task rows", (await page.locator(".internal-tasks .task-status").allTextContents()).every(text => text.trim() === ""));
    const shapes = [];
    for (const [id, label] of [["task-source", "Working"], ["task-review", "Finished"], ["task-check", "Failed"], ["task-blocked", "Blocked"]]) {
      const status = task(id).locator(".task-status");
      check(`${label}: tooltip and accessible state remain available`, await status.getAttribute("title") === label && await status.getAttribute("aria-label") === label && await status.getAttribute("role") === "img");
      check(`${label}: same compact status column`, (await status.boundingBox()).width === 14);
      if (id !== "task-source") {
        shapes.push(await status.locator("svg").innerHTML());
        check(`${label}: terminal and blocked marks do not animate`, await status.locator("svg").evaluate(element => getComputedStyle(element).animationName === "none"));
      }
    }
    check("Finished, failed and blocked have distinct shapes, not just colors", new Set(shapes).size === 3);
    check("Only working tasks have a spinner", await task("task-source").locator(".task-spinner").count() === 1 && await task("task-review").locator(".task-spinner").count() === 0 && await task("task-blocked").locator(".task-spinner").count() === 0);
    check("Spinner uses the established green and working animation", await task("task-source").locator(".task-spinner").evaluate(element => getComputedStyle(element).borderTopColor === "rgb(122, 219, 161)" && getComputedStyle(element).animationName === "working-spin"));
    check("Task lines are one compact row", (await task("task-source").locator(".task-line").boundingBox()).height === 24);
    check("Connector has a shared spine and a short branch elbow", await task("task-source").evaluate(element => getComputedStyle(element, "::before").borderLeftWidth === "1px") && await task("task-source").locator(".task-line").evaluate(element => getComputedStyle(element, "::before").width === "8px"));
    check("Last branch stops at its own line", await task("task-check").evaluate(element => getComputedStyle(element, "::before").height === "12px"));
    await task("task-source").locator(".task-name").click();
    check("Clicking a task never changes active tab or ownership", await model() === initial);
    await task("task-source").locator(".task-name").click({ button: "right" });
    check("Internal task right-click does not open a fabricated tab menu", !await page.locator("#context-menu").isVisible());
    await page.keyboard.press("Escape");
    const beforeHover = await task("task-source").locator(".task-line").evaluate(element => getComputedStyle(element).boxShadow);
    await task("task-source").hover();
    check("Internal tasks do not inherit interactive tab-card elevation", await task("task-source").locator(".task-line").evaluate(element => getComputedStyle(element).boxShadow) === beforeHover && beforeHover === "none");

    for (const grouping of ["subagents", "workspace", "worktrees"]) {
      await page.locator(`[data-grouping="${grouping}"]`).click();
      check(`${grouping}: task group remains attached to the exact tab`, await page.locator('[data-task-parent="implementer"] [data-observed="task-source"]').count() === 1);
      check(`${grouping}: interactive child agent retains its icon and chat target`, await page.locator('[data-row="implementer"] .identity-icon').count() === 1 && await page.locator('[data-row="implementer"] [data-focus="implementer"]').count() === 1);
      check(`${grouping}: internal tasks never become native tabs`, await page.locator('[data-native-surface^="task-"], [data-drag^="task-"]').count() === 0);
      check(`${grouping}: grouping preserves tab identity and active selection`, await model() === initial);
    }
    await page.evaluate(() => {
      observedChildren.push(
        { id: "task-unknown", parent: "implementer", name: "Unverified task", state: "unknown" },
        { id: "task-cancelled", parent: "implementer", name: "Cancelled task", state: "cancelled", outcome: "cancel-1" }
      );
      render();
    });
    await eye.click();
    check("Eye reveals idle internal tasks", await task("task-idle").count() === 1);
    check("Eye never reveals unknown or cancelled tasks", await task("task-unknown").count() === 0 && await task("task-cancelled").count() === 0);
    check("Finished tasks are not hidden by the eye", await task("task-review").count() === 1);
    await page.locator('[data-workspace-collapse="scratch"]').click();
    check("Idle reveal is workspace-local", await task("task-notes").count() === 0);
    await page.locator('[data-toggle-finished="scratch"]').click();
    check("Second workspace can independently reveal its idle tasks", await task("task-notes").count() === 1);
    await eye.click();
    check("Turning first eye off preserves the second workspace choice", await task("task-idle").count() === 0 && await task("task-notes").count() === 1);
    await page.locator('[data-grouping="workspace"]').click();
    const realTabs = await page.locator("[data-native-surface]").evaluateAll(elements => elements.map(element => element.dataset.nativeSurface));
    await eye.click();
    assert.deepEqual(await page.locator("[data-native-surface]").evaluateAll(elements => elements.map(element => element.dataset.nativeSurface)), realTabs);
    check("Native Workspace eye changes task visibility without hiding real tabs", await task("task-idle").count() === 1);
    await eye.click();

    await page.locator('[data-grouping="worktrees"]').click();
    const beforeDismiss = await model();
    await page.keyboard.press("Tab");
    await task("task-review").locator(".task-dismiss").focus();
    check("Dismiss is discoverable with visible keyboard focus", await task("task-review").locator(".task-dismiss").evaluate(element => getComputedStyle(element).opacity === "1" && getComputedStyle(element).outlineStyle !== "none"));
    await page.keyboard.press("Space");
    check("Dismissing hides only the exact finished outcome", await task("task-review").count() === 0 && await task("task-check").count() === 1 && await model() === beforeDismiss);
    check("Dismissing restores focus without selecting a new tab", await page.evaluate(() => document.activeElement.dataset.focus === "implementer" && state.active === "implementer"));
    await eye.click();
    check("Eye does not resurrect a dismissed outcome", await task("task-review").count() === 0);
    await page.reload();
    check("Exact outcome dismissal persists across reload", await task("task-review").count() === 0);
    await page.evaluate(() => {
      const task = observedChildren.find(item => item.id === "task-review");
      task.state = "working"; render();
    });
    check("Renewed work returns a previously dismissed task with a working spinner", await task("task-review").locator(".task-spinner").count() === 1);
    await page.evaluate(() => {
      const task = observedChildren.find(item => item.id === "task-review");
      task.state = "done"; task.outcome = "review-turn-2"; render();
    });
    check("A new finished outcome remains visible and does not keep spinning", await task("task-review").count() === 1 && await task("task-review").locator(".task-spinner").count() === 0);
    await page.evaluate(() => { observedChildren.find(item => item.id === "task-review").outcome = "review-turn-3"; });
    await task("task-review").locator(".task-dismiss").click();
    check("Stale dismiss action cannot hide a newer outcome", await task("task-review").count() === 1 && (await page.locator("#notice").textContent()).includes("Task outcome changed"));
    await page.evaluate(() => {
      const task = observedChildren.find(item => item.id === "task-review");
      state.taskDismissals[taskOutcomeKey(task)] = true;
      task.attention = true; render();
    });
    check("Outstanding attention overrides dismissal without offering dismiss", await task("task-review").count() === 1 && await task("task-review").locator("button").count() === 0 && (await task("task-review").locator(".task-status").getAttribute("aria-label")).includes("needs attention") && await task("task-review").locator(".task-attention").count() === 1);
    await page.evaluate(() => {
      state.workspaceFinished.design = false;
      observedChildren.push({ id: "task-nested", parent: "task-idle", name: "Inspect nested source", state: "working" });
      render();
    });
    check("Idle internal ancestry survives for working descendants", await task("task-idle").locator('[data-task-parent="task-idle"] [data-observed="task-nested"]').count() === 1);
    await page.evaluate(() => { observedChildren.find(item => item.id === "task-nested").state = "idle"; render(); });
    check("Ancestry hides again when no relevant descendant remains", await task("task-idle").count() === 0);
    await page.evaluate(() => {
      observedChildren.push({ id: "task-keep-parent", parent: "researcher", name: "Check references", state: "working" });
      state.collapsed["design:main"] = false;
      render();
    });
    check("A normally filtered tab remains reachable for relevant internal work", await page.locator('[data-row="researcher"] + [data-task-parent="researcher"]').count() === 1);
    await page.evaluate(() => {
      const task = observedChildren.find(item => item.id === "task-source");
      task.state = "done"; task.outcome = "source-turn-1"; render();
    });
    check("Working parent does not keep a finished child spinning", await task("task-source").locator(".task-spinner").count() === 0 && await task("task-source").locator(".task-status").getAttribute("aria-label") === "Finished");

    await page.reload();
    await page.locator("#reset-demo").click();
    await page.emulateMedia({ reducedMotion: "reduce" });
    check("Reduce Motion keeps the working arc and accessible state without animation", await task("task-source").locator(".task-spinner").evaluate(element => getComputedStyle(element).animationName === "none" && getComputedStyle(element).borderRightColor === "rgba(0, 0, 0, 0)") && await task("task-source").locator(".task-status").getAttribute("aria-label") === "Working");
    await page.evaluate(() => {
      observedChildren.find(item => item.id === "task-source").name = 'Inspect <script> sidebar hierarchy and every nested keyboard navigation boundary';
      render();
    });
    for (const width of [280, 350, 460]) {
      await page.locator("#sidebar-width").fill(String(width));
      for (const grouping of ["worktrees", "subagents", "workspace"]) {
        await page.locator(`[data-grouping="${grouping}"]`).click();
        check(`${width}px ${grouping}: no horizontal sidebar overflow`, await page.locator("#sidebar").evaluate(element => element.scrollWidth <= element.clientWidth));
        check(`${width}px ${grouping}: task line fits and status never truncates`, await task("task-source").locator(".task-line").evaluate(element => element.scrollWidth <= element.clientWidth) && await task("task-source").locator(".task-status").evaluate(element => element.scrollWidth <= element.clientWidth));
      }
    }
    check("Full long task names remain accessible and escaped", await task("task-source").locator(".task-name").getAttribute("title") === await task("task-source").locator(".task-name").textContent() && await task("task-source").locator("script").count() === 0);
    await page.reload();
    await page.locator("#reset-demo").click();
    for (const width of [280, 350]) {
      await page.locator("#sidebar-width").fill(String(width));
      await page.mouse.move(1400, 40);
      await page.locator("#workspaces").evaluate(element => { element.scrollTop = 0; });
      await page.locator("#sidebar").screenshot({ path: path.join(artifacts, `review-internal-tasks-${width}.png`) });
    }
    await page.locator('[data-grouping="subagents"]').click();
    await page.mouse.move(1400, 40);
    await page.locator("#workspaces").evaluate(element => { element.scrollTop = 0; });
    await page.locator("#sidebar").screenshot({ path: path.join(artifacts, "review-internal-tasks-tree.png") });
    check("No runtime errors", errors.length === 0);
    check("No external requests or live integration", requests.every(url => url.startsWith(baseURL)));
    console.log(`PASS: ${checks.length} internal-task checks.`);
  } finally {
    await browser.close();
  }
})().catch(error => { console.error(error); process.exitCode = 1; });
