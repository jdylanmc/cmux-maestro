const { chromium } = require("playwright");
const assert = require("node:assert/strict");
const path = require("node:path");

(async () => {
  const browser = await chromium.launch({ channel: "chrome", headless: true });
  const checks = [], errors = [];
  const check = (name, condition) => { assert.ok(condition, name); checks.push(name); };
  try {
    const page = await browser.newPage({ viewport: { width: 1512, height: 1080 }, reducedMotion: "no-preference" });
    page.on("pageerror", error => errors.push(error.message));
    await page.goto(process.env.PROTOTYPE_URL || "http://127.0.0.1:8765/");
    await page.locator("#reset-demo").click();
    await page.mouse.move(1400, 60);
    const original = await page.evaluate(() => JSON.stringify(state));
    const style = row => row.evaluate(element => {
      const css = getComputedStyle(element);
      return { background: css.backgroundColor, shadow: css.boxShadow, transform: css.transform, duration: css.transitionDuration };
    });
    const finish = row => row.evaluate(async element => {
      const transitions = element.getAnimations().filter(animation => animation instanceof CSSTransition);
      await Promise.all(transitions.map(animation => animation.finished));
    });
    let lifted;
    for (const id of ["implementer", "reviewer", "github", "shell"]) {
      const row = page.locator(`[data-row="${id}"]`);
      await row.scrollIntoViewIfNeeded();
      await page.mouse.move(1400, 60);
      await finish(row);
      const initial = await style(row);
      const bounds = await row.boundingBox();
      await row.hover();
      const transition = await row.evaluate(element => {
        const shadow = element.getAnimations().find(animation => animation instanceof CSSTransition && animation.transitionProperty === "box-shadow");
        if (!shadow) return null;
        shadow.pause();
        const duration = shadow.effect.getTiming().duration;
        shadow.currentTime = 0;
        const start = getComputedStyle(element).boxShadow;
        shadow.currentTime = duration / 2;
        const middle = getComputedStyle(element).boxShadow;
        shadow.currentTime = duration;
        const end = getComputedStyle(element).boxShadow;
        shadow.play();
        return { duration, start, middle, end };
      });
      check(`${id}: shadow animates through an intermediate elevation`, transition?.duration === 160 && transition.start !== transition.middle && transition.middle !== transition.end);
      await finish(row);
      lifted = await style(row);
      check(`${id}: background lightens and shadow lifts`, lifted.background !== initial.background && lifted.shadow !== initial.shadow);
      check(`${id}: lift does not translate or resize the row`, lifted.transform === "none" && JSON.stringify(await row.boundingBox()) === JSON.stringify(bounds));
      check(`${id}: overflow button blends into the lifted card`, await row.locator(".row-accessory").evaluate(element => getComputedStyle(element).backgroundColor) === lifted.background);
      for (const selector of [".identity-icon", ".row-main"]) {
        const button = row.locator(selector);
        await button.hover();
        const inner = await style(button);
        check(`${id} ${selector}: no separate hover background or shadow`, inner.background === "rgba(0, 0, 0, 0)" && inner.shadow === "none");
        check(`${id} ${selector}: whole row retains one continuous lift`, (await style(row)).background === lifted.background && (await style(row)).shadow === lifted.shadow);
      }
      await row.locator(".row-accessory").hover();
      check(`${id}: hovering overflow does not add a second surface`, (await style(row.locator(".row-accessory"))).background === lifted.background && (await style(row.locator(".row-accessory"))).shadow === "none");
      if (id === "implementer") {
        check("Selected-row indicator remains visible during lift", await row.evaluate(element => getComputedStyle(element, "::before").width === "3px"));
      }
      await page.mouse.move(1400, 60);
      await finish(row);
      check(`${id}: pointer departure restores its prior appearance`, JSON.stringify(await style(row)) === JSON.stringify(initial));
    }
    check("Hovering never changes selection, identity, preferences or lifecycle", await page.evaluate(() => JSON.stringify(state)) === original);
    const reviewer = page.locator('[data-row="reviewer"]');
    await reviewer.scrollIntoViewIfNeeded();
    await reviewer.locator(".identity-icon").focus();
    await page.keyboard.press("Tab");
    await finish(reviewer);
    check("Keyboard focus gets the same elevation as pointer hover", (await style(reviewer)).shadow === lifted.shadow && (await style(reviewer)).background === lifted.background);
    check("Keyboard focus remains visible", await reviewer.locator(".row-main").evaluate(element => element.matches(":focus-visible") && getComputedStyle(element).outlineStyle !== "none"));
    check("Keyboard focus does not add an inner card", (await style(reviewer.locator(".row-main"))).background === "rgba(0, 0, 0, 0)" && (await style(reviewer.locator(".row-main"))).shadow === "none");
    await page.keyboard.press("Escape");
    await page.locator("#global-grouping button").first().focus();
    await finish(reviewer);
    check("Leaving keyboard focus removes the lift", (await style(reviewer)).shadow !== lifted.shadow);
    await reviewer.locator(".row-main").click();
    await page.mouse.move(1400, 60);
    await finish(reviewer);
    check("Pointer selection does not leave a stuck keyboard lift", (await style(reviewer)).shadow !== lifted.shadow);

    for (const selector of [".workspace-title", ".group-heading", "#pinned-details .detail-field"]) {
      await page.locator("#global-grouping button").first().focus();
      const element = page.locator(selector).first();
      const before = (await style(element)).shadow;
      await element.hover();
      await finish(element);
      check(`${selector}: excluded from row lift`, (await style(element)).shadow === before);
    }
    await page.locator("#beats-button").click();
    await page.locator('[data-grouping="workspace"]').click();
    const utility = page.locator('[data-row="tool-beats"]');
    await utility.hover();
    check("Utility rows do not gain the requested agent/surface elevation", (await style(utility)).shadow === "none");

    await page.locator("#reset-demo").click();
    await page.emulateMedia({ reducedMotion: "reduce" });
    await reviewer.hover();
    check("Reduce Motion keeps the same static card treatment", (await style(reviewer)).background === lifted.background && (await style(reviewer)).shadow === lifted.shadow);
    check("Reduce Motion suppresses row and accessory transitions", (await style(reviewer)).duration.split(",").every(value => Number.parseFloat(value) === 0) && await reviewer.locator(".row-accessory").evaluate(element => Number.parseFloat(getComputedStyle(element).transitionDuration) === 0));
    await page.emulateMedia({ reducedMotion: "no-preference" });
    await page.locator("#global-grouping button").first().focus();
    await page.mouse.move(1400, 60);
    await page.locator("#notice.visible").waitFor({ state: "hidden" });
    await page.locator("#workspaces").evaluate(element => { element.scrollTop = 0; });
    await page.locator("#sidebar").screenshot({ path: path.join(__dirname, "review-lift-idle.png") });
    await reviewer.locator(".row-name").hover();
    await finish(reviewer);
    await page.locator("#sidebar").screenshot({ path: path.join(__dirname, "review-lift-hover.png") });
    for (const grouping of ["subagents", "workspace"]) {
      await page.locator(`[data-grouping="${grouping}"]`).click();
      await reviewer.hover();
      await finish(reviewer);
      check(`${grouping}: row lift is consistent`, (await style(reviewer)).shadow === lifted.shadow);
    }
    await page.locator("#sidebar-width").fill("280");
    check("Narrow sidebar retains its original width without overflow", await page.locator("#sidebar").evaluate(element => element.scrollWidth <= element.clientWidth));
    check("No JavaScript errors", errors.length === 0);
    console.log(`PASS: ${checks.length} row-lift checks.`);
  } finally {
    await browser.close();
  }
})().catch(error => { console.error(error); process.exitCode = 1; });
